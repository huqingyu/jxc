var online=new Array();
if (!document.layers)
document.write('<div id=divStayTopLeft style=position:absolute>');
